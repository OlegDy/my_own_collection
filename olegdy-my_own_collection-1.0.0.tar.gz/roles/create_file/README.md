Role Name
=========

Создание файла

Requirements
------------

olegdy.my_own_collections

Role Variables
--------------

path - Путь для создания файла
content - Наполнение создаваемого файла


Example Playbook
----------------

    ---
    - hosts: localhost
      roles:
         - create_file

License
-------

MIT

Author Information
------------------

Oleg Dy
